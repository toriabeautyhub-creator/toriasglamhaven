# Toria's Glam Haven, Deploy to Vercel (toriasglam.co.ke)

This folder is your whole website. Structure:

```
index.html              the site
images/                 your logo + product photos
api/mpesa-stk.js        sends the M-Pesa STK prompt (needs your Daraja keys)
api/mpesa-callback.js   receives Safaricom's payment confirmation
```

You can open `index.html` on your computer to preview it. Hosting it live takes about 15 minutes.

---

## Step 1, Put the site on Vercel (free)

The no-terminal way:

1. Create a free account at **github.com**.
2. Click **New repository**, name it `torias-glam-haven`, and on the next screen choose **uploading an existing file**. Drag in everything from this folder (index.html, the images folder, the api folder). Commit.
3. Create a free account at **vercel.com** (sign in with GitHub).
4. In Vercel click **Add New > Project**, pick your `torias-glam-haven` repo, and click **Deploy**. No build settings needed, it's a static site with serverless functions; Vercel detects both automatically.
5. In a minute you'll get a live link like `torias-glam-haven.vercel.app`. Open it to confirm the site works.

(Prefer the command line? Install Node, run `npm i -g vercel`, then `vercel` inside this folder.)

## Step 2, Connect your domain

1. In your Vercel project: **Settings > Domains > Add**, type **toriasglam.co.ke**, and add **www.toriasglam.co.ke** too.
2. Vercel will show you the exact DNS records to create. Usually it's:
   - an **A record** for `@` pointing to a Vercel IP (Vercel shows the current one, commonly `76.76.21.21`), and
   - a **CNAME** for `www` pointing to `cname.vercel-dns.com`.
   Use whatever Vercel displays, those are authoritative.
3. Log into **Truehost > your domain > DNS / Zone Editor**, and add exactly those records.
4. Wait for it to propagate (often minutes, up to a few hours). Vercel will tick the domain green and add HTTPS automatically.

That's it, toriasglam.co.ke now shows your site.

## Step 3, Turn on live M-Pesa STK push

The site already has a working manual option (Paybill **400200**, Account **1075861**) and the WhatsApp order flow, so you can take orders immediately. To make the automatic STK pop-up work:

1. Apply for the **Daraja API** at developer.safaricom.co.ke (free). Create an app and request "Lipa na M-Pesa Online" for Paybill **400200**. You'll get a **Consumer Key**, **Consumer Secret** and **Passkey**.
2. In Vercel: **Settings > Environment Variables**, add:
   - `MPESA_CONSUMER_KEY` = your key
   - `MPESA_CONSUMER_SECRET` = your secret
   - `MPESA_PASSKEY` = your passkey
   - `MPESA_SHORTCODE` = `400200`
   - `MPESA_ENV` = `sandbox` (switch to `production` when approved)
   - `MPESA_CALLBACK_URL` = `https://toriasglam.co.ke/api/mpesa-callback`
3. **Redeploy** (Vercel > Deployments > Redeploy) so the new variables take effect.
4. Test checkout with sandbox, then set `MPESA_ENV=production` once Safaricom approves you for go-live.

**Don't want the Daraja wait?** Use an aggregator instead (IntaSend or Pesapal). They give you M-Pesa STK for a small per-sale fee with no Daraja approval. If you choose that route, tell me and I'll swap the payment step to their checkout.

## Step 4, Editing the site later

- **Add or change a product:** open `index.html`, find the `PRODUCTS` list near the bottom (clearly laid out, one line per product), and edit the name, price, `was` (sale) price, category or `img`. To add a photo, drop the image file into `images/` and reference it like `img:'images/your-photo.jpg'`. Re-upload to GitHub and Vercel redeploys automatically.
- **Discount codes:** edit the `CODES` list in the same file.
- I'm happy to make any of these edits for you, just send me the change.

---

## Costs

- Domain: about KES 1,000 / year (already paid)
- Vercel hosting: **free**
- M-Pesa: free via Daraja, or small per-sale fee via an aggregator

So your only fixed cost is the yearly domain.
