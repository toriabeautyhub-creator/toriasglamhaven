// /api/mpesa-stk  ,  Safaricom Daraja STK push (Paybill 400200)
// Set these in Vercel > Project > Settings > Environment Variables:
//   MPESA_CONSUMER_KEY, MPESA_CONSUMER_SECRET, MPESA_PASSKEY
//   MPESA_SHORTCODE=400200, MPESA_ENV=sandbox (or production)
//   MPESA_CALLBACK_URL=https://toriasglam.co.ke/api/mpesa-callback

export default async function handler(req, res) {
  if (req.method !== 'POST') { res.status(405).json({ message: 'POST only' }); return; }

  const { phone, amount, account } = req.body || {};
  const {
    MPESA_CONSUMER_KEY, MPESA_CONSUMER_SECRET, MPESA_PASSKEY,
    MPESA_SHORTCODE = '400200', MPESA_ENV = 'sandbox', MPESA_CALLBACK_URL
  } = process.env;

  if (!MPESA_CONSUMER_KEY || !MPESA_CONSUMER_SECRET || !MPESA_PASSKEY) {
    res.status(500).json({ message: 'M-Pesa not configured. Add Daraja env vars in Vercel.' });
    return;
  }

  const base = MPESA_ENV === 'production'
    ? 'https://api.safaricom.co.ke'
    : 'https://sandbox.safaricom.co.ke';

  // normalise phone to 2547XXXXXXXX / 2541XXXXXXXX
  let msisdn = String(phone || '').replace(/\D/g, '');
  if (msisdn.startsWith('0')) msisdn = '254' + msisdn.slice(1);
  else if (msisdn.startsWith('7') || msisdn.startsWith('1')) msisdn = '254' + msisdn;

  try {
    // 1) OAuth token
    const auth = Buffer.from(`${MPESA_CONSUMER_KEY}:${MPESA_CONSUMER_SECRET}`).toString('base64');
    const tokRes = await fetch(`${base}/oauth/v1/generate?grant_type=client_credentials`, {
      headers: { Authorization: `Basic ${auth}` }
    });
    const tok = await tokRes.json();
    if (!tok.access_token) { res.status(502).json({ message: 'Auth failed', detail: tok }); return; }

    // 2) STK push
    const ts = new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14);
    const password = Buffer.from(`${MPESA_SHORTCODE}${MPESA_PASSKEY}${ts}`).toString('base64');
    const payload = {
      BusinessShortCode: MPESA_SHORTCODE,
      Password: password,
      Timestamp: ts,
      TransactionType: 'CustomerPayBillOnline',  // Paybill
      Amount: Math.max(1, Math.round(Number(amount) || 0)),
      PartyA: msisdn,
      PartyB: MPESA_SHORTCODE,
      PhoneNumber: msisdn,
      CallBackURL: MPESA_CALLBACK_URL || 'https://toriasglam.co.ke/api/mpesa-callback',
      AccountReference: String(account || 'TGH').slice(0, 12),
      TransactionDesc: 'Torias Glam Haven order'
    };
    const stkRes = await fetch(`${base}/mpesa/stkpush/v1/processrequest`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${tok.access_token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await stkRes.json();
    res.status(200).json(data); // contains ResponseCode "0" on success
  } catch (e) {
    res.status(500).json({ message: 'STK error', detail: String(e) });
  }
}
