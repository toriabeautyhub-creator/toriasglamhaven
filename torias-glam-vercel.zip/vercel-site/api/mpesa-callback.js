// /api/mpesa-callback  ,  Safaricom posts the payment result here after the customer enters their PIN.
// For now it just acknowledges and logs. To mark orders paid automatically you'd save the
// result (e.g. to a database or Vercel KV) and match it to the order by AccountReference.

export default async function handler(req, res) {
  try {
    console.log('M-PESA CALLBACK:', JSON.stringify(req.body));
    // Example of what you receive:
    // req.body.Body.stkCallback.ResultCode === 0  => success
    // ...CallbackMetadata.Item => Amount, MpesaReceiptNumber, PhoneNumber
  } catch (e) {
    console.error('callback parse error', e);
  }
  // Always 200 so Safaricom stops retrying
  res.status(200).json({ ResultCode: 0, ResultDesc: 'Received' });
}
